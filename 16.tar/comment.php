<?php
// comment.php
include 'config.php';

// Створення таблиці для коментарів, якщо її ще не існує
$create_table = "CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

mysqli_query($conn, $create_table);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['name']) && isset($_POST['comment'])) {
        $name = $_POST['name'];
        $comment = $_POST['comment'];
        
        // Вразливий код - нема фільтрації вхідних даних
        $query = "INSERT INTO comments (name, comment) VALUES ('$name', '$comment')";
        
        if (mysqli_query($conn, $query)) {
            header("Location: index.php");
            exit();
        } else {
            echo "Помилка: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Помилка</title>
</head>
<body>
    <h1>Помилка при додаванні відгуку</h1>
    <p>Будь ласка, переконайтеся, що ви заповнили всі поля.</p>
    <p><a href="index.php">Повернутися на головну</a></p>
</body>
</html>