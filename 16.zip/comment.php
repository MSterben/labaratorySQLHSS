<?php
// comment.php
include 'config.php';

// Створення таблиці для коментарів, якщо її ще не існує
$create_table = "CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

mysqli_query($conn, $create_table);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['name']) && isset($_POST['comment'])) {
        $name = $_POST['name'];
        $comment = $_POST['comment'];
        
        // Вразливий код - немає фільтрації вхідних даних
        // Це дозволяє XSS атаки через збереження шкідливого коду в базі даних
        $query = "INSERT INTO comments (name, comment) VALUES ('$name', '$comment')";
        
        if (mysqli_query($conn, $query)) {
            // Додаємо затримку для демонстрації
            sleep(1);
            header("Location: index.php?success=1");
            exit();
        } else {
            $error_message = mysqli_error($conn);
        }
    } else {
        $error_message = "Будь ласка, заповніть всі поля.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Обробка коментаря</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            background: linear-gradient(135deg, #ff6b6b, #feca57);
            min-height: 100vh;
        }
        .container { 
            width: 600px; 
            margin: 50px auto; 
            background: white; 
            padding: 30px; 
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            border: 1px solid #f5c6cb;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            border: 1px solid #c3e6cb;
        }
        .warning {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            border: 1px solid #ffeaa7;
        }
        .back-btn {
            display: inline-block;
            background: #007bff;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 20px;
        }
        .back-btn:hover {
            background: #0056b3;
        }
        .debug-info {
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            font-family: monospace;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (isset($error_message)): ?>
            <div class="error">
                <h2>❌ Помилка при додаванні відгуку</h2>
                <p><strong>Деталі помилки:</strong> <?php echo htmlspecialchars($error_message); ?></p>
            </div>
            
            <div class="warning">
                <h3>⚠️ Інформація для дебагу</h3>
                <p>Можливо, ви використовували спеціальні символи або SQL код у своєму коментарі.</p>
                <p>Цей додаток вразливий до XSS та SQL Injection атак!</p>
            </div>
            
            <?php if (isset($_POST['name']) && isset($_POST['comment'])): ?>
                <div class="debug-info">
                    <h4>🔍 Отримані дані:</h4>
                    <p><strong>Ім'я:</strong> <?php echo htmlspecialchars($_POST['name']); ?></p>
                    <p><strong>Коментар:</strong> <?php echo htmlspecialchars($_POST['comment']); ?></p>
                    <p><strong>Розмір коментаря:</strong> <?php echo strlen($_POST['comment']); ?> символів</p>
                    <p><strong>Містить HTML теги:</strong> <?php echo (strip_tags($_POST['comment']) != $_POST['comment']) ? 'Так' : 'Ні'; ?></p>
                    <p><strong>Містить JavaScript:</strong> <?php echo (stripos($_POST['comment'], 'script') !== false) ? 'Так' : 'Ні'; ?></p>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div class="success">
                <h2>✅ Коментар успішно додано!</h2>
                <p>Ваш коментар було збережено в базі даних без будь-якої фільтрації.</p>
            </div>
            
            <div class="warning">
                <h3>🚨 Увага - XSS вразливість!</h3>
                <p>Якщо ви ввели HTML або JavaScript код, він буде виконано при відображенні на головній сторінці.</p>
                <p>Це демонструє небезпеку Stored XSS атак!</p>
            </div>
        <?php endif; ?>
        
        <div style="text-align: center;">
            <a href="index.php" class="back-btn">🏠 Повернутися на головну сторінку</a>
        </div>
        
        <div class="debug-info">
            <h4>📊 Технічна інформація:</h4>
            <p><strong>Час обробки:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
            <p><strong>IP адреса:</strong> <?php echo $_SERVER['REMOTE_ADDR']; ?></p>
            <p><strong>User Agent:</strong> <?php echo htmlspecialchars(substr($_SERVER['HTTP_USER_AGENT'], 0, 100)); ?>...</p>
            <p><strong>Метод запиту:</strong> <?php echo $_SERVER['REQUEST_METHOD']; ?></p>
        </div>
    </div>
</body>
</html>