<?php
// index.php
include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Вразливий веб-додаток</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .container { width: 800px; margin: 0 auto; }
        .form-group { margin-bottom: 15px; }
        input[type="text"] { padding: 5px; width: 300px; }
        button { padding: 5px 10px; }
        .result { margin-top: 20px; border: 1px solid #ccc; padding: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Демонстраційний веб-додаток</h1>
        
        <h2>Пошук користувача (SQL Injection)</h2>
        <form action="search.php" method="GET">
            <div class="form-group">
                <label>Ім'я користувача:</label>
                <input type="text" name="username" placeholder="Введіть ім'я користувача">
            </div>
            <button type="submit">Пошук</button>
        </form>
        
        <h2>Відгуки (XSS)</h2>
        <form action="comment.php" method="POST">
            <div class="form-group">
                <label>Ваше ім'я:</label>
                <input type="text" name="name" placeholder="Введіть ваше ім'я">
            </div>
            <div class="form-group">
                <label>Ваш відгук:</label>
                <textarea name="comment" rows="4" cols="50" placeholder="Введіть ваш відгук"></textarea>
            </div>
            <button type="submit">Додати відгук</button>
        </form>
        
        <h2>Останні відгуки:</h2>
        <div class="comments">
            <?php
            $query = "SELECT * FROM comments ORDER BY id DESC LIMIT 10";
            $result = mysqli_query($conn, $query);
            
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<div class='comment'>";
                    echo "<strong>" . $row['name'] . "</strong> сказав(ла):<br>";
                    echo $row['comment']; // Вразливість XSS - відсутня фільтрація
                    echo "</div><hr>";
                }
            } else {
                echo "Відгуків поки немає.";
            }
            ?>
        </div>
    </div>
</body>
</html>
