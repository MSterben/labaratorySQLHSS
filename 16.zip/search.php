<?php
// search.php
include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Результати пошуку</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }
        .container { width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        table { border-collapse: collapse; width: 100%; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .query-display { background: #e8e8e8; padding: 10px; border-radius: 4px; margin: 10px 0; font-family: monospace; }
        .warning { background: #ffebee; color: #c62828; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .sensitive { background: #fff3e0; border-left: 4px solid #ff9800; padding: 10px; margin: 10px 0; }
        .admin-data { background: #f3e5f5; border-left: 4px solid #9c27b0; padding: 10px; margin: 10px 0; }
        .access-denied { background: #ffcdd2; border-left: 4px solid #f44336; padding: 15px; margin: 10px 0; }
        .normal-search { background: #e8f5e8; border-left: 4px solid #4caf50; padding: 10px; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Результати пошуку користувачів</h1>
        
        <?php
        if (isset($_GET['username'])) {
            $username = $_GET['username'];
            
            // Перевіряємо, чи це SQL injection атака
            $is_sql_injection = false;
            $injection_patterns = array(
                "' OR '1'='1",
                "' OR 1=1",
                "' OR true",
                "' OR 'a'='a",
                "' OR '1'='1' --",
                "' OR 1=1 --",
                "admin' --",
                "admin'/*",
                "' UNION SELECT",
                "' union select",
                "1' OR '1'='1",
                "admin' OR '1'='1",
                "'; DROP TABLE",
                "'; drop table"
            );
            
            foreach ($injection_patterns as $pattern) {
                if (stripos($username, $pattern) !== false || 
                    stripos($username, str_replace("'", '"', $pattern)) !== false) {
                    $is_sql_injection = true;
                    break;
                }
            }
            
            // Якщо це звичайний пошук (не SQL injection)
            if (!$is_sql_injection) {
                // Обмежуємо пошук тільки звичайними користувачами (не адміном)
                $safe_query = "SELECT * FROM users WHERE username LIKE '%" . mysqli_real_escape_string($conn, $username) . "%' AND username != 'admin'";
                
                echo "<div class='query-display'>";
                echo "<strong>Виконаний SQL запит (захищений):</strong><br>" . htmlspecialchars($safe_query);
                echo "</div>";
                
                $result = mysqli_query($conn, $safe_query);
                
                if ($result && mysqli_num_rows($result) > 0) {
                    echo "<div class='normal-search'>";
                    echo "<h3>✅ Знайдені користувачі:</h3>";
                    echo "</div>";
                    echo "<table>";
                    echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Статус</th></tr>";
                    
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['username'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td><span style='color: green;'>Звичайний користувач</span></td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                    
                    // Якщо шукали admin, показуємо повідомлення про обмеження доступу
                    if (stripos($username, 'admin') !== false) {
                        echo "<div class='access-denied'>";
                        echo "<h3>🔒 Доступ обмежено!</h3>";
                        echo "<p><strong>Системне повідомлення:</strong> Дані адміністратора захищені та не відображаються в результатах пошуку.</p>";
                        echo "<p>Для отримання адміністративних даних потрібні спеціальні права доступу.</p>";
                        echo "</div>";
                    }
                    
                } else {
                    echo "<div class='access-denied'>";
                    echo "<h3>❌ Користувачів не знайдено</h3>";
                    if (stripos($username, 'admin') !== false) {
                        echo "<p><strong>Увага:</strong> Адміністративні облікові записи не відображаються в публічному пошуку з міркувань безпеки.</p>";
                    } else {
                        echo "<p>Спробуйте інший пошуковий запит.</p>";
                    }
                    echo "</div>";
                }
            } 
            // Якщо це SQL injection атака
            else {
                echo "<div class='warning'>";
                echo "<h3>🚨 ВИЯВЛЕНО SQL INJECTION АТАКУ!</h3>";
                echo "<p>Система безпеки обійдена! Зловмисник отримав доступ до захищених даних!</p>";
                echo "</div>";
                
                // Вразливий до SQL Injection запит (без захисту)
                $vulnerable_query = "SELECT * FROM users WHERE username LIKE '%" . $username . "%'";
                
                echo "<div class='query-display' style='background: #ffcdd2;'>";
                echo "<strong>Скомпрометований SQL запит:</strong><br>" . htmlspecialchars($vulnerable_query);
                echo "</div>";
                
                $result = mysqli_query($conn, $vulnerable_query);
                
                if ($result) {
                    if (mysqli_num_rows($result) > 0) {
                        echo "<div class='admin-data'>";
                        echo "<h3>💀 ВИТІК ДАНИХ - Всі користувачі системи:</h3>";
                        echo "</div>";
                        echo "<table>";
                        echo "<tr><th>ID</th><th>Username</th><th>Password</th><th>Email</th><th>Рівень загрози</th></tr>";
                        
                        while ($row = mysqli_fetch_assoc($result)) {
                            $threat_level = ($row['username'] == 'admin') ? 'КРИТИЧНИЙ' : 'Високий';
                            $row_color = ($row['username'] == 'admin') ? 'background: #ffebee;' : '';
                            
                            echo "<tr style='$row_color'>";
                            echo "<td>" . $row['id'] . "</td>";
                            echo "<td>";
                            if ($row['username'] == 'admin') {
                                echo "<strong style='color: red;'>👑 " . $row['username'] . "</strong>";
                            } else {
                                echo $row['username'];
                            }
                            echo "</td>";
                            echo "<td><span style='background: red; color: white; padding: 2px 5px; border-radius: 3px;'>" . $row['password'] . "</span></td>";
                            echo "<td>" . $row['email'] . "</td>";
                            echo "<td><span style='color: " . (($threat_level == 'КРИТИЧНИЙ') ? 'red' : 'orange') . "; font-weight: bold;'>$threat_level</span></td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                        
                        // Демонстрація отримання додаткових даних через UNION attack
                        if (strpos($username, 'UNION') !== false || strpos($username, 'union') !== false) {
                            // Показуємо адміністраторські дані
                            echo "<div class='admin-data'>";
                            echo "<h3>🔓 ДОДАТКОВИЙ ВИТІК - Дані адміністраторів системи:</h3>";
                            $admin_query = "SELECT * FROM admin_users";
                            $admin_result = mysqli_query($conn, $admin_query);
                            
                            if ($admin_result && mysqli_num_rows($admin_result) > 0) {
                                echo "<table>";
                                echo "<tr><th>ID</th><th>Admin Username</th><th>Admin Password</th><th>Email</th><th>Privileges</th></tr>";
                                while ($admin_row = mysqli_fetch_assoc($admin_result)) {
                                    echo "<tr style='background: #f3e5f5;'>";
                                    echo "<td>" . $admin_row['id'] . "</td>";
                                    echo "<td><strong>🔑 " . $admin_row['admin_username'] . "</strong></td>";
                                    echo "<td><span style='background: darkred; color: white; padding: 2px 5px;'>" . $admin_row['admin_password'] . "</span></td>";
                                    echo "<td>" . $admin_row['admin_email'] . "</td>";
                                    echo "<td><span style='color: purple; font-weight: bold;'>" . $admin_row['privileges'] . "</span></td>";
                                    echo "</tr>";
                                }
                                echo "</table>";
                            }
                            echo "</div>";
                            
                            // Показуємо конфіденційні дані
                            echo "<div class='sensitive'>";
                            echo "<h3>📋 КРИТИЧНИЙ ВИТІК - Конфіденційні документи:</h3>";
                            $sensitive_query = "SELECT * FROM sensitive_data";
                            $sensitive_result = mysqli_query($conn, $sensitive_query);
                            
                            if ($sensitive_result && mysqli_num_rows($sensitive_result) > 0) {
                                while ($sensitive_row = mysqli_fetch_assoc($sensitive_result)) {
                                    echo "<div style='margin: 10px 0; padding: 15px; border: 2px solid #ff5722; background: #fff3e0; border-radius: 5px;'>";
                                    echo "<h4>🚨 " . $sensitive_row['document_name'] . " (Рівень: " . $sensitive_row['access_level'] . ")</h4>";
                                    echo "<p><strong>Викрадена конфіденційна інформація:</strong><br>";
                                    echo "<em style='color: #d32f2f; background: #ffebee; padding: 5px; border-radius: 3px;'>" . $sensitive_row['confidential_info'] . "</em></p>";
                                    echo "</div>";
                                }
                            }
                            echo "</div>";
                        }
                    } else {
                        echo "<p>Користувачів не знайдено навіть після SQL injection.</p>";
                    }
                } else {
                    echo "<div class='warning'>";
                    echo "<h3>Помилка SQL:</h3>";
                    echo "<p>" . mysqli_error($conn) . "</p>";
                    echo "</div>";
                }
            }
        }
        ?>
                
        <div style="margin-top: 20px; padding: 15px; background: #fff3cd; border-radius: 4px;">
            <h3>🎯 Очікуваний результат для студентів:</h3>
            <ul>
                <li><strong>Пошук "admin":</strong> Повідомлення "Доступ обмежено" - дані адміна захищені</li>
                <li><strong>Пошук "user1":</strong> Показує тільки звичайного користувача</li>
                <li><strong>SQL Injection ' OR '1'='1:</strong> Показує ВСІ записи включно з паролем адміна!</li>
            </ul>
        </div>
        
        <p><a href="index.php" style="background: #2196f3; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px;">Повернутися на головну</a></p>
    </div>
</body>
</html>