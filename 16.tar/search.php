<?php
// search.php
include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Результати пошуку</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .container { width: 800px; margin: 0 auto; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Результати пошуку</h1>
        
        <?php
        if (isset($_GET['username'])) {
            $username = $_GET['username'];
            
            // Вразливий до SQL Injection запит - нема підготовлених запитів
            $query = "SELECT * FROM users WHERE username LIKE '%" . $username . "%'";
            $result = mysqli_query($conn, $query);
            
            echo "<p>Запит: " . $query . "</p>";
            
            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    echo "<table>";
                    echo "<tr><th>ID</th><th>Username</th><th>Email</th></tr>";
                    
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['username'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "</tr>";
                    }
                    
                    echo "</table>";
                } else {
                    echo "Користувачів не знайдено.";
                }
            } else {
                echo "Помилка: " . mysqli_error($conn);
            }
        }
        ?>
        
        <p><a href="index.php">Повернутися на головну</a></p>
    </div>
</body>
</html>
