<?php
// config.php
$db_host = 'localhost';
$db_user = 'vulnuser';
$db_pass = 'password123';
$db_name = 'vulnerable_db';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Створення додаткових таблиць для демонстрації
$create_admin_table = "CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_username VARCHAR(50),
    admin_password VARCHAR(100),
    admin_email VARCHAR(100),
    privileges VARCHAR(100),
    last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

$create_sensitive_data = "CREATE TABLE IF NOT EXISTS sensitive_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_name VARCHAR(100),
    confidential_info TEXT,
    access_level VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

mysqli_query($conn, $create_admin_table);
mysqli_query($conn, $create_sensitive_data);

// Додавання тестових даних для адміністраторів
$check_admin = "SELECT COUNT(*) as count FROM admin_users";
$result = mysqli_query($conn, $check_admin);
$row = mysqli_fetch_assoc($result);

if ($row['count'] == 0) {
    $insert_admins = "INSERT INTO admin_users (admin_username, admin_password, admin_email, privileges) VALUES
    ('superadmin', 'TopSecret123!', 'super@company.com', 'FULL_ACCESS'),
    ('dbadmin', 'DatabasePass456', 'db@company.com', 'DATABASE_ADMIN'),
    ('sysadmin', 'SystemAccess789', 'sys@company.com', 'SYSTEM_ADMIN')";
    
    mysqli_query($conn, $insert_admins);
}

// Додавання конфіденційних даних
$check_sensitive = "SELECT COUNT(*) as count FROM sensitive_data";
$result = mysqli_query($conn, $check_sensitive);
$row = mysqli_fetch_assoc($result);

if ($row['count'] == 0) {
    $insert_sensitive = "INSERT INTO sensitive_data (document_name, confidential_info, access_level) VALUES
    ('Фінансовий звіт 2024', 'Прибуток компанії: 2,500,000 грн. Збитки: 150,000 грн. Секретні інвестиції в проект Alpha.', 'TOP_SECRET'),
    ('База клієнтів', 'Номери кредитних карт: 4532-1234-5678-9012, 5555-4444-3333-2222. Паролі: client123, secure456', 'CONFIDENTIAL'),
    ('Зарплати співробітників', 'Директор: 50,000 грн/міс, Менеджер: 25,000 грн/міс, Програміст: 35,000 грн/міс', 'INTERNAL')";
    
    mysqli_query($conn, $insert_sensitive);
}
?>